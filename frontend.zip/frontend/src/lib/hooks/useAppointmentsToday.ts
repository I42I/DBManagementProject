import { useEffect, useState } from 'react'
import { appointments, toISOZ, type Appointment } from '../../lib/api/appointments'

type Row = Appointment & {
  patient_identifier?: string
  patient_name?: string
}

export function useAppointmentsToday() {
  const [data, setData] = useState<Row[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    async function load() {
      try {
        const now = new Date()
        const start = new Date(now); start.setHours(0,0,0,0)
        const end   = new Date(now); end.setHours(23,59,59,999)

        const list = await appointments.list({
          date_from: toISOZ(start),
          date_to: toISOZ(end),
        })
        setData(list as Row[])
      } catch (e: any) {
        setError(e.message || 'Erreur')
      } finally {
        setLoading(false)
      }
    }
    load()
  }, [])

  return { data, loading, error }
}
