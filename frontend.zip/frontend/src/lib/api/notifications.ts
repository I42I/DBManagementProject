import { http } from '../http'

// ----- Types alignés sur le backend -----

export type NotifChannel = 'sms' | 'email' | 'push'
export type NotifStatus  = 'queued' | 'sent' | 'failed' | 'read'
export type NotifRefType = 'appointment' | 'consultation' | 'prescription' | 'payment' | 'other'

export type Notification = {
  _id: string
  channel: NotifChannel
  status: NotifStatus
  template?: string
  payload?: Record<string, any>
  ref_type?: NotifRefType
  ref_id?: string
  to_patient_id?: string
  to_doctor_id?: string
  send_at?: string     // ISO
  sent_at?: string     // ISO
  expires_at?: string  // ISO
  error?: string
  created_at?: string
  updated_at?: string
  deleted?: boolean
}

export type NewNotification = {
  channel: NotifChannel
  status: NotifStatus
  template?: string
  payload?: Record<string, any> | null
  ref_type?: NotifRefType
  ref_id?: string
  to_patient_id?: string
  to_doctor_id?: string
  send_at?: string     // ISO
  sent_at?: string     // ISO
  expires_at?: string  // ISO (TTL côté DB si index configuré)
  error?: string
}

// ----- Client -----

export const notifications = {
  /**
   * Liste avec filtres facultatifs:
   * - status, channel, ref_type (strings)
   * - to_patient_id, to_doctor_id (ObjectId strings)
   * Tri: created_at desc. Limite 200 côté back.
   */
  list: (params?: {
    status?: NotifStatus
    channel?: NotifChannel
    ref_type?: NotifRefType
    to_patient_id?: string
    to_doctor_id?: string
  }) => {
    const qs = new URLSearchParams()
    if (params?.status) qs.set('status', params.status)
    if (params?.channel) qs.set('channel', params.channel)
    if (params?.ref_type) qs.set('ref_type', params.ref_type)
    if (params?.to_patient_id) qs.set('to_patient_id', params.to_patient_id)
    if (params?.to_doctor_id) qs.set('to_doctor_id', params.to_doctor_id)
    const suffix = qs.toString() ? `?${qs.toString()}` : ''
    return http<Notification[]>(`/api/notifications${suffix}`)
  },

  getById: (id: string) => http<Notification>(`/api/notifications/${id}`),

  // POST -> back renvoie { _id } uniquement : on refetch ensuite le détail
  createAndFetch: async (body: NewNotification) => {
    const created = await http<{ _id: string }>(`/api/notifications`, {
      method: 'POST',
      body: JSON.stringify(body),
    })
    return notifications.getById(created._id)
  },
}
