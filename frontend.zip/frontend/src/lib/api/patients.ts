import { http } from '../http'

// Item renvoyé par GET /api/patients (projection légère)
export type PatientListItem = {
  _id: string
  identite: {
    prenom: string
    nom: string
    // date_naissance peut ne pas être renvoyée par la liste -> optionnelle ici
    date_naissance?: string
    sexe?: 'M' | 'F' | 'X'
  }
  contacts?: { phone?: string }
  facility_id?: string
  created_at?: string
  updated_at?: string
}

// Document complet renvoyé par GET /api/patients/:id
export type PatientFull = PatientListItem & {
  // ajoute ici d'autres champs que tu stockes en détail (adresse, etc.)
}

// Corps attendu par POST /api/patients
export type NewPatient = {
  facility_id?: string
  identite: {
    prenom: string
    nom: string
    date_naissance: string   // ISO ex: "2001-05-12T00:00:00Z"
    sexe: 'M' | 'F' | 'X'
  }
  contacts?: { phone?: string }
  // autres champs optionnels…
}

export const patients = {
  // liste (avec q/limit/skip facultatifs)
  list: (params?: { q?: string; limit?: number; skip?: number }) => {
    const qs = new URLSearchParams()
    if (params?.q) qs.set('q', params.q)
    if (params?.limit) qs.set('limit', String(params.limit))
    if (params?.skip) qs.set('skip', String(params.skip))
    const suffix = qs.toString() ? `?${qs.toString()}` : ''
    return http<PatientListItem[]>(`/api/patients${suffix}`)
  },

  // détail
  getById: (id: string) => http<PatientFull>(`/api/patients/${id}`),

  // création -> ton back renvoie { _id }, donc on refetch le détail juste après
  createAndFetch: async (body: NewPatient) => {
    const created = await http<{ _id: string }>(`/api/patients`, {
      method: 'POST',
      body: JSON.stringify(body),
    })
    return patients.getById(created._id)
  },
}
