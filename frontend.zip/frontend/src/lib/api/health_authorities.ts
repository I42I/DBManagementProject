import { http } from '../http'

// ---------- Types alignés sur ton backend ----------

export type ReportType = 'case_summary' | 'disease_reporting' | 'inventory' | 'other'
export type ReportStatus = 'draft' | 'submitted' | 'accepted' | 'rejected'

export type HealthAuthorityReport = {
  _id: string
  facility_id: string
  report_type: ReportType
  period_start: string   // ISO (avec Z si UTC)
  period_end: string     // ISO
  status: ReportStatus
  payload?: Record<string, any>
  external_ref?: string | null
  notes?: string | null
  submitted_at?: string
  created_at?: string
  updated_at?: string
  deleted?: boolean
}

export type NewHealthAuthorityReport = {
  facility_id: string                 // ObjectId string
  report_type: ReportType
  period_start: string                // ISO 8601
  period_end: string                  // ISO 8601
  status?: ReportStatus               // défaut "draft" côté back
  payload?: Record<string, any>
  external_ref?: string | null
  notes?: string | null
  submitted_at?: string               // ISO 8601 (optionnel)
}

// Helper: forcer un ISO avec Z depuis un Date JS
export function toISOZ(d: Date | string) {
  if (typeof d === 'string') return d
  return d.toISOString() // inclut 'Z'
}

// ---------- Client HTTP ----------

export const healthAuthorities = {
  /**
   * Liste avec filtres facultatifs:
   * - facility_id
   * - report_type
   * - status
   * Trie: created_at desc (limite 200)
   */
  list: (params?: {
    facility_id?: string
    report_type?: ReportType
    status?: ReportStatus
  }) => {
    const qs = new URLSearchParams()
    if (params?.facility_id) qs.set('facility_id', params.facility_id)
    if (params?.report_type) qs.set('report_type', params.report_type)
    if (params?.status) qs.set('status', params.status)
    const suffix = qs.toString() ? `?${qs.toString()}` : ''
    return http<HealthAuthorityReport[]>(`/api/health_authorities${suffix}`)
  },

  getById: (id: string) =>
    http<HealthAuthorityReport>(`/api/health_authorities/${id}`),

  // Création -> le back renvoie { _id } seulement, donc on refetch le détail
  createAndFetch: async (body: NewHealthAuthorityReport) => {
    const created = await http<{ _id: string }>(`/api/health_authorities`, {
      method: 'POST',
      body: JSON.stringify(body),
    })
    return healthAuthorities.getById(created._id)
  },
}
