import { http } from '../http'

// ---------- Types (calqués sur ton backend) ----------

export type Consultation = {
  _id: string
  patient_id: string
  doctor_id: string
  facility_id: string
  appointment_id?: string
  date_time: string              // ISO 8601 (avec Z si UTC)
  symptomes?: any
  diagnostic?: any
  notes?: any
  vital_signs?: any
  attachments?: any
  created_at?: string
  updated_at?: string
  deleted?: boolean
}

export type NewConsultation = {
  patient_id: string            // ObjectId (string)
  doctor_id: string             // ObjectId (string)
  facility_id?: string          // optionnel (généré sinon)
  appointment_id?: string       // optionnel
  date_time: string             // ISO 8601 ("2025-10-31T12:00:00Z")
  symptomes?: any
  diagnostic?: any
  notes?: any
  vital_signs?: any
  attachments?: any
}

// ---------- Helpers ----------

// Force un ISO "Z" depuis un Date JS si besoin
export function toISOZ(d: Date | string) {
  if (typeof d === 'string') return d
  return d.toISOString()
}

// ---------- Client HTTP ----------

export const consultations = {
  // /api/consultations?patient_id=&doctor_id=&facility_id=
  list: (params?: { patient_id?: string; doctor_id?: string; facility_id?: string }) => {
    const qs = new URLSearchParams()
    if (params?.patient_id) qs.set('patient_id', params.patient_id)
    if (params?.doctor_id) qs.set('doctor_id', params.doctor_id)
    if (params?.facility_id) qs.set('facility_id', params.facility_id)
    const suffix = qs.toString() ? `?${qs.toString()}` : ''
    return http<Consultation[]>(`/api/consultations${suffix}`)
  },

  getById: (id: string) => http<Consultation>(`/api/consultations/${id}`),

  // POST renvoie { _id } → on refetch immédiatement le document complet
  createAndFetch: async (body: NewConsultation) => {
    const created = await http<{ _id: string }>(`/api/consultations`, {
      method: 'POST',
      body: JSON.stringify(body),
    })
    return consultations.getById(created._id)
  },
}
