import { http } from '../http'

// ----- Types alignés sur le backend -----

export type PharmacyStatus = 'requested' | 'prepared' | 'dispensed' | 'cancelled'

export type PharmacyItem = {
  dci: string
  qty: number
  brand?: string
  forme?: string
  posologie?: string
  notes?: string
}

export type Pharmacy = {
  _id: string
  patient_id: string
  doctor_id: string
  facility_id: string
  prescription_id?: string
  status: PharmacyStatus
  items: PharmacyItem[]
  dispensed_at?: string       // ISO si présent
  created_at?: string
  updated_at?: string
  deleted?: boolean
}

export type NewPharmacy = {
  patient_id: string                // ObjectId string
  doctor_id: string                 // ObjectId string
  facility_id?: string              // optionnel (généré sinon)
  prescription_id?: string          // optionnel
  status: PharmacyStatus            // required par _validate_create
  items: Array<{
    dci: string
    qty: number | string            // le back accepte string numérique, mais number recommandé
    brand?: string
    forme?: string
    posologie?: string
    notes?: string
    // quantity?: number | string    // si tu tiens à envoyer "quantity", normalisé côté back -> qty
  }>
  dispensed_at?: string             // ISO 8601
}

// ----- Client -----

export const pharmacies = {
  /**
   * Liste avec filtres facultatifs:
   * - patient_id / doctor_id / facility_id (ObjectId strings)
   * - status (requested|prepared|dispensed|cancelled)
   * Tri: created_at desc, limit 200
   */
  list: (params?: {
    patient_id?: string
    doctor_id?: string
    facility_id?: string
    status?: PharmacyStatus
  }) => {
    const qs = new URLSearchParams()
    if (params?.patient_id) qs.set('patient_id', params.patient_id)
    if (params?.doctor_id) qs.set('doctor_id', params.doctor_id)
    if (params?.facility_id) qs.set('facility_id', params.facility_id)
    if (params?.status) qs.set('status', params.status)
    const suffix = qs.toString() ? `?${qs.toString()}` : ''
    return http<Pharmacy[]>(`/api/pharmacies${suffix}`)
  },

  // Détail
  getById: (id: string) => http<Pharmacy>(`/api/pharmacies/${id}`),

  // Création -> le back renvoie { _id } uniquement, donc on refetch ensuite le détail
  createAndFetch: async (body: NewPharmacy) => {
    const created = await http<{ _id: string }>(`/api/pharmacies`, {
      method: 'POST',
      body: JSON.stringify(body),
    })
    return pharmacies.getById(created._id)
  },
}

