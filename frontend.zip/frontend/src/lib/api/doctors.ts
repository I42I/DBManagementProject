import { http } from '../http'

// ===== Types alignés sur ton backend =====

// Item renvoyé par GET /api/doctors (projection légère)
export type DoctorListItem = {
  _id: string
  identite: {
    prenom: string
    nom: string
  }
  specialites: string[]
  facility_id?: string
}

// Document complet renvoyé par GET /api/doctors/:id
export type DoctorFull = DoctorListItem & {
  // ajoute ici d’autres champs si ta collection en contient
  created_at?: string
  updated_at?: string
  deleted?: boolean
}

// Corps attendu par POST /api/doctors
export type NewDoctor = {
  facility_id?: string
  identite: {
    prenom: string
    nom: string
  }
  specialites: string[] // tableau non vide de strings non vides
}

// ===== Client =====

export const doctors = {
  // /api/doctors?specialite=Cardio&facility_id=...
  list: (params?: { specialite?: string; facility_id?: string; limit?: number }) => {
    const qs = new URLSearchParams()
    if (params?.specialite) qs.set('specialite', params.specialite)
    if (params?.facility_id) qs.set('facility_id', params.facility_id)
    // ton endpoint limite déjà à 200 côté back; on garde limit ici si jamais tu l’ajoutes plus tard
    if (params?.limit) qs.set('limit', String(params.limit))
    const suffix = qs.toString() ? `?${qs.toString()}` : ''
    return http<DoctorListItem[]>(`/api/doctors${suffix}`)
  },

  // détail
  getById: (id: string) => http<DoctorFull>(`/api/doctors/${id}`),

  // création -> ton back renvoie { _id } seulement, donc on refetch le détail
  createAndFetch: async (body: NewDoctor) => {
    const created = await http<{ _id: string }>(`/api/doctors`, {
      method: 'POST',
      body: JSON.stringify(body),
    })
    return doctors.getById(created._id)
  },
}
