import { http } from '../http'

// ----- Types alignés sur le backend -----

export type LabStatus = 'ordered' | 'in_progress' | 'completed' | 'cancelled'

export type LabTest = {
  code: string
  name: string
  status: string            // tu laisses libre côté back; on garde string
  result?: string | number
  unit?: string
  ref_range?: string
  abnormal?: boolean
}

export type Laboratory = {
  _id: string
  patient_id: string
  doctor_id: string
  facility_id: string
  appointment_id?: string
  status: LabStatus
  date_ordered: string       // ISO (créé côté back)
  date_reported?: string     // ISO si completed
  tests?: LabTest[]
  notes?: string
  created_at?: string
  updated_at?: string
  deleted?: boolean
}

export type NewLaboratory = {
  patient_id: string              // ObjectId string
  doctor_id: string               // ObjectId string
  facility_id?: string            // optionnel (généré sinon)
  appointment_id?: string         // optionnel
  status: LabStatus               // required par ton _validate
  tests?: LabTest[]               // optionnel, si présent: objets code/name/status (+ champs optionnels)
  notes?: string
}

// ----- Client -----

export const laboratories = {
  /**
   * Liste avec filtres facultatifs:
   * - patient_id / doctor_id / facility_id (ObjectId strings)
   * - status (ordered|in_progress|completed|cancelled)
   * Tri: date_ordered desc, limit 200
   */
  list: (params?: {
    patient_id?: string
    doctor_id?: string
    facility_id?: string
    status?: LabStatus
  }) => {
    const qs = new URLSearchParams()
    if (params?.patient_id) qs.set('patient_id', params.patient_id)
    if (params?.doctor_id) qs.set('doctor_id', params.doctor_id)
    if (params?.facility_id) qs.set('facility_id', params.facility_id)
    if (params?.status) qs.set('status', params.status)
    const suffix = qs.toString() ? `?${qs.toString()}` : ''
    return http<Laboratory[]>(`/api/laboratories${suffix}`)
  },

  // Détail
  getById: (id: string) => http<Laboratory>(`/api/laboratories/${id}`),

  // Création -> le back renvoie { _id } uniquement, on refetch ensuite le détail
  createAndFetch: async (body: NewLaboratory) => {
    const created = await http<{ _id: string }>(`/api/laboratories`, {
      method: 'POST',
      body: JSON.stringify(body),
    })
    return laboratories.getById(created._id)
  },
}
