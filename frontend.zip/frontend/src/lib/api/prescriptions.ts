import { http } from '../http'

// -------- Types alignés sur ton backend --------

export type PrescriptionItem = {
  dci: string
  forme?: string
  posologie: string
  duree_j?: number | string
  contre_indications?: string
}

export type Prescription = {
  _id: string
  patient_id: string
  doctor_id: string
  consultation_id: string
  facility_id?: string
  items: PrescriptionItem[]
  renouvellements?: number
  notes?: string
  created_at?: string
  updated_at?: string
  deleted?: boolean
}

export type NewPrescription = {
  patient_id: string              // ObjectId string
  doctor_id: string               // ObjectId string
  consultation_id: string         // ObjectId string
  facility_id?: string
  items: PrescriptionItem[]       // non vide; chaque item: dci + posologie requis
  renouvellements?: number
  notes?: string
}

// -------- Client HTTP --------

export const prescriptions = {
  /**
   * Liste avec filtres facultatifs:
   * - patient_id / doctor_id / consultation_id / facility_id
   * Tri: created_at desc, limite 200
   */
  list: (params?: {
    patient_id?: string
    doctor_id?: string
    consultation_id?: string
    facility_id?: string
  }) => {
    const qs = new URLSearchParams()
    if (params?.patient_id) qs.set('patient_id', params.patient_id)
    if (params?.doctor_id) qs.set('doctor_id', params.doctor_id)
    if (params?.consultation_id) qs.set('consultation_id', params.consultation_id)
    if (params?.facility_id) qs.set('facility_id', params.facility_id)
    const suffix = qs.toString() ? `?${qs.toString()}` : ''
    return http<Prescription[]>(`/api/prescriptions${suffix}`)
  },

  getById: (id: string) => http<Prescription>(`/api/prescriptions/${id}`),

  // POST -> le back renvoie { _id } uniquement : on refetch le détail
  createAndFetch: async (body: NewPrescription) => {
    const created = await http<{ _id: string }>(`/api/prescriptions`, {
      method: 'POST',
      body: JSON.stringify(body),
    })
    return prescriptions.getById(created._id)
  },
}
