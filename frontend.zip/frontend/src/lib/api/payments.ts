import { http } from '../http'

// -------- Types alignés sur ton backend --------

export type Currency = 'XAF' | 'XOF' | 'EUR' | 'USD'
export type PayMethod = 'cash' | 'card' | 'mobile' | 'insurance'
export type PayStatus =
  | 'pending'
  | 'paid'
  | 'failed'
  | 'refunded'
  | 'cancelled'

export type PaymentItem = {
  ref_type?: 'appointment' | 'consultation' | 'laboratory' | 'pharmacy' | 'other'
  ref_id?: string
  label?: string
  amount?: number
}

export type Payment = {
  _id: string
  patient_id: string
  facility_id: string
  appointment_id?: string
  consultation_id?: string
  invoice_no?: string
  amount: number
  currency: Currency
  method: PayMethod
  status: PayStatus
  items?: PaymentItem[]
  due_date?: string     // ISO 8601
  paid_at?: string      // ISO 8601
  created_at?: string
  updated_at?: string
  deleted?: boolean
}

export type NewPayment = {
  patient_id: string                 // ObjectId string
  facility_id?: string               // optionnel (généré sinon)
  appointment_id?: string
  consultation_id?: string
  invoice_no?: string
  amount: number
  currency: Currency
  method?: PayMethod                 // défaut "cash" côté back
  status: PayStatus                  // requis par ton _validate
  items?: PaymentItem[]
  due_date?: string                  // ISO
  paid_at?: string                   // ISO
}

// Petit helper si tu pars d'un Date JS
export function toISOZ(d: Date | string) {
  if (typeof d === 'string') return d
  return d.toISOString()
}

// -------- Client HTTP --------

export const payments = {
  /**
   * Liste avec filtres facultatifs:
   * - patient_id, facility_id (ObjectId strings)
   * - status, currency, method
   * Tri: created_at desc, limite 200.
   */
  list: (params?: {
    patient_id?: string
    facility_id?: string
    status?: PayStatus
    currency?: Currency
    method?: PayMethod
  }) => {
    const qs = new URLSearchParams()
    if (params?.patient_id) qs.set('patient_id', params.patient_id)
    if (params?.facility_id) qs.set('facility_id', params.facility_id)
    if (params?.status) qs.set('status', params.status)
    if (params?.currency) qs.set('currency', params.currency)
    if (params?.method) qs.set('method', params.method)
    const suffix = qs.toString() ? `?${qs.toString()}` : ''
    return http<Payment[]>(`/api/payments${suffix}`)
  },

  getById: (id: string) => http<Payment>(`/api/payments/${id}`),

  // Création -> le back renvoie { _id } uniquement : on refetch ensuite le détail
  createAndFetch: async (body: NewPayment) => {
    const created = await http<{ _id: string }>(`/api/payments`, {
      method: 'POST',
      body: JSON.stringify(body),
    })
    return payments.getById(created._id)
  },
}
