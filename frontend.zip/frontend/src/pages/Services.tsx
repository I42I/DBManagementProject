import React from 'react'
import { Link } from 'react-router-dom'

export default function Services() {
  const services = [
    { title: 'Rendez-vous', text: 'Planifiez une visite chez un spécialiste.', link: '/appointments', icon: '/images/icon-appointment.svg' },
    { title: 'Prescriptions', text: 'Gérez vos ordonnances et alertes.', link: '/services', icon: '/images/icon-prescription.svg' },
    { title: 'Laboratoires', text: 'Consultez vos résultats d’analyse.', link: '/results', icon: '/images/icon-lab.svg' },
    { title: 'Pharmacies', text: 'Trouvez une pharmacie partenaire.', link: '/services', icon: '/images/icon-pharmacy.svg' },
  ]
  return (
    <div className="container py-10">
      <h2 className="h2 mb-6">Tous les services</h2>
      <div className="grid md:grid-cols-4 gap-6">
        {services.map(s => <div key={s.title} className="card p-6">
          <img src={s.icon} className="h-10 mb-2" /><h3 className="font-semibold">{s.title}</h3>
          <p className="text-sm text-slate-600 mb-3">{s.text}</p>
          <Link className="text-primary font-medium" to={s.link}>Accéder →</Link>
        </div>)}
      </div>
    </div>
  )
}