import React from 'react'
import { motion } from 'framer-motion'
import { Link } from 'react-router-dom'

export default function Home() {
  return (<>
    <section className="bg-white">
      <div className="container grid md:grid-cols-2 gap-10 items-center py-16">
        <div>
          <motion.h1 className="h1 mb-4" initial={{opacity:0, y:20}} animate={{opacity:1, y:0}} transition={{duration:0.6}}>
            Votre santé, au cœur du Tchad
          </motion.h1>
          <p className="text-slate-600 mb-6">Un portail simple pour gérer vos rendez-vous, consulter vos résultats et communiquer avec les professionnels de santé — accessible, mobile et sécurisé.</p>
          <div className="flex gap-3">
            <Link to="/appointments" className="btn-primary">Prendre rendez-vous</Link>
            <Link to="/results" className="btn-outline">Consulter mes résultats</Link>
          </div>
        </div>
        <motion.div initial={{opacity:0}} animate={{opacity:1}} transition={{delay:0.2}}>
          <img src="/images/hero-illustration.svg" alt="Illustration santé" className="w-full" />
        </motion.div>
      </div>
    </section>

    <section className="py-12">
      <div className="container">
        <h2 className="h2 mb-6">Services principaux</h2>
        <div className="grid md:grid-cols-3 gap-6">
          {cards.map((c, i) => (
            <motion.div key={i} className="card p-6" initial={{opacity:0, y:8}} whileInView={{opacity:1, y:0}} viewport={{once:true}} transition={{delay:i*0.05}}>
              <img src={c.icon} alt="" className="h-12 mb-3" />
              <h3 className="font-semibold mb-1">{c.title}</h3>
              <p className="text-sm text-slate-600 mb-4">{c.desc}</p>
              <Link to={c.link} className="text-primary font-medium">Accéder →</Link>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  </>)
}

const cards = [
  { title: 'Rendez-vous', desc: 'Planifiez une consultation près de chez vous.', link: '/appointments', icon: '/images/icon-appointment.svg' },
  { title: 'Prescriptions', desc: 'Retrouvez vos ordonnances en ligne.', link: '/services', icon: '/images/icon-prescription.svg' },
  { title: 'Laboratoires', desc: 'Consultez vos résultats d’analyse.', link: '/results', icon: '/images/icon-lab.svg' },
]