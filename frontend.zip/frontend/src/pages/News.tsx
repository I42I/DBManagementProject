import React from 'react'
export default function News() {
  const items = [
    { title:'Campagne de vaccination', date:'2025-10-05', excerpt:"Nouvelle campagne de vaccination à N'Djamena." },
    { title:'Nouveau laboratoire partenaire', date:'2025-09-18', excerpt:"Ouverture d'un centre moderne à Moundou." },
  ]
  return (
    <div className="container py-10">
      <h2 className="h2 mb-6">Actualités</h2>
      <div className="grid md:grid-cols-2 gap-6">
        {items.map(n => <article key={n.title} className="card p-6">
          <h3 className="font-semibold">{n.title}</h3>
          <p className="text-sm text-slate-500 mb-2">{n.date}</p>
          <p className="text-sm">{n.excerpt}</p>
        </article>)}
      </div>
    </div>
  )
}