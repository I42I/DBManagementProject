import React from 'react'
import { Link } from 'react-router-dom'

export default function Patients() {
  const tips = [
    "Apportez votre pièce d’identité et carnet de santé.",
    "Arrivez 15 minutes en avance pour les formalités.",
    "En cas d’urgence, appelez les numéros officiels."
  ]
  return (
    <div className="container py-10">
      <h2 className="h2 mb-4">Espace Patients</h2>
      <p className="text-slate-600 mb-6">Une interface simple pour tous : prenez rendez-vous, suivez vos soins et accédez à vos résultats.</p>
      <div className="grid md:grid-cols-3 gap-6 mb-10">
        <div className="card p-6"><h3 className="font-semibold mb-2">Prendre rendez-vous</h3><p className="text-sm text-slate-600 mb-3">Choisissez la date, le lieu et le spécialiste.</p><Link to="/appointments" className="btn-primary">Commencer</Link></div>
        <div className="card p-6"><h3 className="font-semibold mb-2">Résultats d’analyses</h3><p className="text-sm text-slate-600 mb-3">Accédez rapidement à vos résultats.</p><Link to="/results" className="btn-outline">Consulter</Link></div>
        <div className="card p-6"><h3 className="font-semibold mb-2">Ordonnances</h3><p className="text-sm text-slate-600 mb-3">Retrouvez vos prescriptions et alertes.</p><Link to="/services" className="btn-outline">Voir</Link></div>
      </div>
      <div className="card p-6"><h3 className="font-semibold mb-3">Conseils utiles</h3>
        <ul className="list-disc pl-5 space-y-2 text-sm">{tips.map(t => <li key={t}>{t}</li>)}</ul>
      </div>
    </div>
  )
}