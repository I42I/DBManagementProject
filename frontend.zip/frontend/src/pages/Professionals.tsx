import React from 'react'
import { useAppointmentsToday } from '../lib/hooks/useAppointmentsToday'

export default function Professionals() {
  const { data, loading, error } = useAppointmentsToday()

  return (
    <div className="container py-10">
      <div className="flex items-center justify-between mb-6">
        <h2 className="h2">Espace Professionnels</h2>
        <button className="btn-primary">Créer une consultation</button>
      </div>

      <div className="grid md:grid-cols-3 gap-6">
        <div className="card p-6 md:col-span-2">
          <h3 className="font-semibold mb-3">Rendez-vous du jour</h3>

          {loading && <p>Chargement…</p>}
          {error && <p className="text-red-600">{error}</p>}

          {!loading && !error && (
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left">
                  <th className="py-2">Patient</th>
                  <th>Heure</th>
                  <th>Statut</th>
                </tr>
              </thead>
              <tbody>
                {data.length === 0 ? (
                  <tr>
                    <td colSpan={3} className="py-6 text-center text-gray-500">
                      Aucun rendez-vous aujourd’hui.
                    </td>
                  </tr>
                ) : (
                  data.map(a => (
                    <tr key={a._id} className="border-t">
                      <td className="py-2">
                        {a.patient_identifier
                          ? `${a.patient_identifier} — ${a.patient_name ?? ''}`
                          : (a.patient_name ?? a.patient_id)}
                      </td>
                      <td>
                        {new Date(a.date_time).toLocaleTimeString([], {
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </td>
                      <td>{a.status}</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          )}
        </div>

        <div className="card p-6">
          <h3 className="font-semibold mb-3">Statistiques</h3>
          <ul className="space-y-2 text-sm">
            <li>Patients vus : <b>{data.length}</b></li>
            <li>En attente : <b>{data.filter(a => a.status === 'scheduled').length}</b></li>
            <li>Annulés : <b>{data.filter(a => a.status === 'cancelled').length}</b></li>
          </ul>
        </div>
      </div>
    </div>
  )
}
