import React, { useState } from 'react'
export default function Contact() {
  const [form, setForm] = useState({ name:'', email:'', message:'' })
  const submit = (e: React.FormEvent) => { e.preventDefault(); alert('Message envoyé (simulation). Merci !') }
  return (
    <div className="container py-10">
      <h2 className="h2 mb-4">Contact</h2>
      <form onSubmit={submit} className="card p-6 max-w-xl">
        <label className="block text-sm font-medium mb-1">Nom</label>
        <input className="border rounded-xl px-3 py-2 mb-3 w-full" value={form.name} onChange={e=>setForm({...form, name:e.target.value})}/>
        <label className="block text-sm font-medium mb-1">Email</label>
        <input className="border rounded-xl px-3 py-2 mb-3 w-full" value={form.email} onChange={e=>setForm({...form, email:e.target.value})}/>
        <label className="block text-sm font-medium mb-1">Message</label>
        <textarea className="border rounded-xl px-3 py-2 mb-4 w-full" rows={4} value={form.message} onChange={e=>setForm({...form, message:e.target.value})}/>
        <button className="btn-primary">Envoyer</button>
      </form>
    </div>
  )
}