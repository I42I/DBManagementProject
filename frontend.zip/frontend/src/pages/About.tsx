import React from 'react'
export default function About() {
  return (
    <div className="container py-10">
      <h2 className="h2 mb-4">À propos</h2>
      <p className="text-slate-600 mb-6 max-w-3xl">CHAD Health est une initiative visant à faciliter l'accès aux services de santé pour tous au Tchad, que vous soyez patient ou professionnel. Notre priorité : simplicité, sécurité et compatibilité sur mobiles.</p>
      <div className="grid md:grid-cols-3 gap-6">
        <div className="card p-6"><b>Simplicité</b><p className="text-sm mt-2">Interface claire et adaptée, même hors connexion partielle.</p></div>
        <div className="card p-6"><b>Sécurité</b><p className="text-sm mt-2">Protection des données et respect de la confidentialité.</p></div>
        <div className="card p-6"><b>Accessibilité</b><p className="text-sm mt-2">Taille de texte ajustable, contraste élevé.</p></div>
      </div>
    </div>
  )
}