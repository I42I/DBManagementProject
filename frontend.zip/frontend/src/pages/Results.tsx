import React, { useState } from 'react'
export default function Results() {
  const [code, setCode] = useState('')
  const [data, setData] = useState<any|null>(null)
  const fetchResult = (e: React.FormEvent) => { e.preventDefault(); setData({ patient: 'Amina D.', exam: 'Hémogramme', date: '2025-10-01', conclusion: 'Valeurs normales.' }) }
  return (
    <div className="container py-10">
      <h2 className="h2 mb-4">Consulter mes résultats</h2>
      <form onSubmit={fetchResult} className="card p-6 mb-6">
        <label className="block mb-2 font-medium">Code de résultat</label>
        <div className="flex gap-2">
          <input className="border rounded-xl px-3 py-2 flex-1" placeholder="Ex: LAB-8F2D9" value={code} onChange={e=>setCode(e.target.value)} />
          <button className="btn-primary">Consulter</button>
        </div>
      </form>
      {data && <div className="card p-6"><h3 className="font-semibold mb-2">Résultat</h3>
        <p className="text-sm"><b>Patient:</b> {data.patient}</p>
        <p className="text-sm"><b>Examen:</b> {data.exam}</p>
        <p className="text-sm"><b>Date:</b> {data.date}</p>
        <p className="text-sm"><b>Conclusion:</b> {data.conclusion}</p>
      </div>}
    </div>
  )
}