import React from 'react'
import { createRoot } from 'react-dom/client'
import { createBrowserRouter, RouterProvider } from 'react-router-dom'

import RootLayout from './layouts/RootLayout'
import Home from './pages/Home'
import Patients from './pages/Patients'
import Professionals from './pages/Professionals'
import Services from './pages/Services'
import News from './pages/News'
import About from './pages/About'
import Contact from './pages/Contact'
import Results from './pages/Results'
import Appointments from './pages/Appointments'
import './index.css'

// 404 simple
function NotFound() {
  return (
    <div style={{ padding: 24 }}>
      <h1>404 Not Found</h1>
      <p>Cette page n’existe pas.</p>
    </div>
  )
}

const router = createBrowserRouter([
  {
    path: '/',
    element: <RootLayout />,
    children: [
      { index: true, element: <Home /> },

      // Patients
      { path: 'patients', element: <Patients /> },

      // Professionnels (FR) et alias (EN)
      { path: 'professionnels', element: <Professionals /> },
      { path: 'professionals',  element: <Professionals /> },

      // Rendez-vous (garde l’anglais + alias FR si tu veux)
      { path: 'appointments', element: <Appointments /> },
      // { path: 'rendez-vous',  element: <Appointments /> }, // <- active si tu veux l’URL FR

      // Autres pages
      { path: 'services', element: <Services /> },
      { path: 'results',  element: <Results /> },
      { path: 'news',     element: <News /> },
      { path: 'about',    element: <About /> },
      { path: 'contact',  element: <Contact /> },

      // 404 pour les sous-routes
      { path: '*', element: <NotFound /> },
    ],
  },

  // 404 globale (au cas où)
  { path: '*', element: <NotFound /> },
])

createRoot(document.getElementById('root')!).render(<RouterProvider router={router} />)
